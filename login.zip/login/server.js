const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const fs = require('fs');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({ secret: 'your-secret-key', resave: true, saveUninitialized: true }));
app.set('view engine', 'ejs');

// Carica le credenziali dal file JSON
const credentials = JSON.parse(fs.readFileSync('credentials.json', 'utf8'));

// Pagina di login
app.get('/', (req, res) => {
  res.render('login');
});

// Pagina di gestione accesso concessa
app.get('/App_GrantedUser', (req, res) => {
  // Assicurati che l'utente sia autenticato prima di consentire l'accesso
  if (req.session && req.session.user) {
    res.render('App_GrantedUser', { user: req.session.user });
  } else {
    res.redirect('/notPermission.htm');
  }
});

// Pagina di non permesso
app.get('/notPermission.htm', (req, res) => {
  res.send('Accesso negato. Effettua il login per accedere.');
});

// Endpoint di autenticazione
app.post('/authenticate', (req, res) => {
  const { username, password } = req.body;

  // Verifica se entrambi i campi sono stati compilati
  if (!username || !password) {
    // Reindirizza alla pagina di errore se uno o entrambi i campi sono vuoti
    res.redirect('/notPermission.htm');
    return;
  }

  // Funzione di autenticazione
  function authenticate(username, password) {
    const user = credentials.find(cred => cred.username === username && cred.password === password);
    return user;
  }

  // Esegui l'autenticazione
  const authenticatedUser = authenticate(username, password);

  if (authenticatedUser) {
    // Memorizza le informazioni dell'utente nella sessione
    req.session.user = authenticatedUser;

    // Aggiungi nuove credenziali al file JSON
    credentials.push({ username, password });

    // Aggiorna il file JSON con le nuove credenziali
    fs.writeFileSync('credentials.json', JSON.stringify(credentials, null, 2), 'utf8');

    // Reindirizza alla pagina di gestione accesso concessa
    res.redirect('/App_GrantedUser');
  } else {
    // Reindirizza alla pagina di non permesso
    res.redirect('/notPermission.htm');
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
